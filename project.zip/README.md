# MC Phone Servers

App Android para crear y correr servidores de Minecraft (Java y Bedrock) usando la RAM del propio teléfono.

- **Java**: Paper.
- **Bedrock**: Paper + Geyser + Floodgate (entran jugadores de Bedrock y de Java al mismo servidor).
- El servidor corre dentro de **Termux** (que aporta Java); la app lo controla y muestra la consola.

## Primer uso
1. Instala Termux (F-Droid o GitHub, no Play Store).
2. Abre MC Phone Servers y sigue la tarjeta "Preparación": pega el comando en Termux, reinícialo, da el permiso y quita el ahorro de batería.
3. Crea un servidor, pulsa **Preparar** (instala Java y descarga todo) y luego **Iniciar**.
4. Conéctate con la IP y puerto que muestra la app (mismo WiFi).

Puertos: Java usa 25565 (TCP). Bedrock usa 19132 (UDP).
