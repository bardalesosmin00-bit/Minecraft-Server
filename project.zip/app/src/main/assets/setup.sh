#!/data/data/com.termux/files/usr/bin/bash
# Se ejecuta dentro de Termux. La app reemplaza los textos __ASI__.
exec 3<>/dev/tcp/127.0.0.1/__CONSOLE_PORT__ || exit 1
exec >&3 2>&1

fail() { echo "@@ERROR@@ $1"; exit 1; }

echo "[termux] Preparando '__DIR__' (edicion: __EDITION__)"
export DEBIAN_FRONTEND=noninteractive

if ! command -v java >/dev/null 2>&1 || ! command -v curl >/dev/null 2>&1 || ! command -v jq >/dev/null 2>&1; then
  echo "[termux] Instalando Java, curl y jq. Puede tardar varios minutos..."
  pkg update -y || echo "[termux] (aviso) pkg update fallo, continuo"
  pkg install -y curl jq || fail "No se pudo instalar curl y jq"
  if ! command -v java >/dev/null 2>&1; then
    pkg install -y openjdk-25 || pkg install -y openjdk-21 || fail "No se pudo instalar Java"
  fi
fi
java -version 2>&1 | head -n 1

DIR="$HOME/mcservers/__DIR__"
mkdir -p "$DIR/plugins" || fail "No se pudo crear la carpeta del servidor"
cd "$DIR" || fail "No se pudo entrar a la carpeta del servidor"

UA="MCPhoneServers/0.1 (app Android personal)"
VER="__VERSION__"
if [ "$VER" = "latest" ]; then
  VER=$(curl -fsS -A "$UA" https://fill.papermc.io/v3/projects/paper | jq -r '.versions | to_entries[0].value[0]')
  [ -n "$VER" ] && [ "$VER" != "null" ] || fail "No se pudo consultar la ultima version de Paper"
fi
echo "[termux] Version de Paper: $VER"

if [ ! -f server.jar ]; then
  URL=$(curl -fsS -A "$UA" "https://fill.papermc.io/v3/projects/paper/versions/$VER/builds" \
    | jq -r '[.[] | select(.channel=="STABLE")][0].downloads["server:default"].url')
  [ -n "$URL" ] && [ "$URL" != "null" ] || fail "No hay build estable de Paper para $VER"
  echo "[termux] Descargando Paper..."
  curl -fL -A "$UA" -o server.jar "$URL" || fail "Fallo la descarga de Paper"
fi

if [ "__EDITION__" = "bedrock" ]; then
  GEY="https://download.geysermc.org/v2/projects"
  if [ ! -f plugins/Geyser-Spigot.jar ]; then
    echo "[termux] Descargando Geyser (permite entrar desde Bedrock)..."
    curl -fL -A "$UA" -o plugins/Geyser-Spigot.jar "$GEY/geyser/versions/latest/builds/latest/downloads/spigot" || fail "Fallo la descarga de Geyser"
  fi
  if [ ! -f plugins/floodgate-spigot.jar ]; then
    echo "[termux] Descargando Floodgate (Bedrock sin cuenta de Java)..."
    curl -fL -A "$UA" -o plugins/floodgate-spigot.jar "$GEY/floodgate/versions/latest/builds/latest/downloads/spigot" || fail "Fallo la descarga de Floodgate"
  fi
fi

if [ ! -f server.properties ]; then
  printf 'server-port=__PORT__\nmax-players=__MAXPLAYERS__\n' > server.properties
fi
echo "eula=true" > eula.txt

echo "@@SETUP_DONE@@"
