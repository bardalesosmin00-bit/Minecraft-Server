#!/data/data/com.termux/files/usr/bin/bash
# Se ejecuta dentro de Termux. La app reemplaza los textos __ASI__.
# El socket (descriptor 3) conecta la consola del servidor con la app.
exec 3<>/dev/tcp/127.0.0.1/__CONSOLE_PORT__ || exit 1

cd "$HOME/mcservers/__DIR__" 2>/dev/null || { echo "@@ERROR@@ La carpeta no existe. Pulsa Preparar primero." >&3; exit 1; }
[ -f server.jar ] || { echo "@@ERROR@@ Falta server.jar. Pulsa Preparar primero." >&3; exit 1; }
command -v java >/dev/null 2>&1 || { echo "@@ERROR@@ Java no esta instalado. Pulsa Preparar." >&3; exit 1; }

echo "[termux] Iniciando con __RAM__ MB de RAM..." >&3
termux-wake-lock 2>/dev/null

java -Xms256M -Xmx__RAM__M -XX:+UseSerialGC -jar server.jar nogui <&3 >&3 2>&1

termux-wake-unlock 2>/dev/null
echo "@@STOPPED@@" >&3
