package com.mcphone.servers

import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors

enum class Phase { IDLE, SETUP, STARTING, RUNNING, STOPPING }

/**
 * Recibe la consola del servidor que corre en Termux por un socket local
 * (127.0.0.1) y permite enviarle comandos.
 */
object ConsoleHub {
    const val PORT = 28765

    var lines by mutableStateOf(listOf<String>())
        private set
    var phase by mutableStateOf(Phase.IDLE)
        private set

    /** La llamará el servicio para cerrarse cuando no haya nada activo. */
    var onIdle: (() -> Unit)? = null

    private val lock = Any()
    private val handler = Handler(Looper.getMainLooper())
    private val writer = Executors.newSingleThreadExecutor()
    private val ansi = Regex("\u001B\\[[0-9;?]*[ -/]*[@-~]")

    @Volatile private var listening = false
    @Volatile private var serverSocket: ServerSocket? = null
    @Volatile private var client: Socket? = null
    @Volatile private var out: OutputStream? = null

    fun begin(newPhase: Phase, title: String) {
        handler.removeCallbacksAndMessages(null)
        synchronized(lock) { lines = emptyList() }
        log("[app] $title")
        phase = newPhase
        startListening()
        handler.postDelayed({
            if (out == null && phase != Phase.IDLE) {
                fail("Termux no respondió en 25 s. Revisa el permiso, la opción allow-external-apps y reinicia Termux.")
            }
        }, 25_000)
    }

    fun log(line: String) {
        synchronized(lock) {
            val next = lines + line
            lines = if (next.size > 800) next.takeLast(800) else next
        }
    }

    fun fail(message: String) {
        log("[app] ERROR: $message")
        finish()
    }

    fun send(text: String) {
        writer.execute {
            try {
                out?.let {
                    it.write((text + "\n").toByteArray())
                    it.flush()
                }
            } catch (_: Exception) {
            }
        }
    }

    fun requestStop() {
        if (phase == Phase.STARTING || phase == Phase.RUNNING) {
            phase = Phase.STOPPING
            log("> stop")
            send("stop")
        }
    }

    fun shutdown() {
        handler.removeCallbacksAndMessages(null)
        listening = false
        try { client?.close() } catch (_: Exception) {}
        try { serverSocket?.close() } catch (_: Exception) {}
        client = null
        serverSocket = null
        out = null
        phase = Phase.IDLE
    }

    private fun finish() {
        handler.removeCallbacksAndMessages(null)
        phase = Phase.IDLE
        onIdle?.invoke()
    }

    private fun handleLine(raw: String) {
        val line = ansi.replace(raw, "").trimEnd()
        when {
            line.startsWith("@@SETUP_DONE@@") -> {
                log("[app] Listo. Ya puedes iniciar el servidor.")
                finish()
            }
            line.startsWith("@@STOPPED@@") -> {
                log("[app] Servidor detenido.")
                finish()
            }
            line.startsWith("@@ERROR@@") -> fail(line.removePrefix("@@ERROR@@").trim())
            else -> {
                if (line.isNotEmpty()) log(line)
                if (phase == Phase.STARTING && line.contains("Done (")) phase = Phase.RUNNING
            }
        }
    }

    private fun startListening() {
        synchronized(lock) {
            if (listening) return
            listening = true
        }
        Thread {
            val ss = try {
                ServerSocket().apply {
                    reuseAddress = true
                    bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), PORT), 1)
                }
            } catch (e: Exception) {
                log("[app] No se pudo abrir el puerto $PORT: ${e.message}")
                listening = false
                finish()
                return@Thread
            }
            serverSocket = ss
            try {
                while (!ss.isClosed) {
                    val s = ss.accept()
                    client = s
                    out = s.getOutputStream()
                    try {
                        s.getInputStream().bufferedReader().forEachLine { handleLine(it) }
                    } catch (_: Exception) {
                    }
                    out = null
                    try { s.close() } catch (_: Exception) {}
                    if (phase != Phase.IDLE) {
                        log("[app] La conexión con Termux terminó")
                        finish()
                    }
                }
            } catch (_: Exception) {
            }
            listening = false
        }.apply { isDaemon = true }.start()
    }
}
