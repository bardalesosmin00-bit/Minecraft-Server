@file:OptIn(ExperimentalMaterial3Api::class)

package com.mcphone.servers

import android.Manifest
import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var servers by remember { mutableStateOf(ServerStore.load(ctx)) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    val selected = servers.firstOrNull { it.id == selectedId }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    BackHandler(enabled = selected != null) { selectedId = null }

    if (selected == null) {
        ServerListScreen(
            servers = servers,
            onOpen = { selectedId = it.id },
            onCreate = { showCreate = true }
        )
    } else {
        ServerScreen(
            server = selected,
            onBack = { selectedId = null },
            onDelete = { s ->
                servers = servers.filter { it.id != s.id }
                ServerStore.save(ctx, servers)
                selectedId = null
            }
        )
    }

    if (showCreate) {
        CreateServerDialog(
            onDismiss = { showCreate = false },
            onCreate = { cfg ->
                servers = servers + cfg
                ServerStore.save(ctx, servers)
                showCreate = false
            }
        )
    }
}

@Composable
fun ServerListScreen(
    servers: List<ServerConfig>,
    onOpen: (ServerConfig) -> Unit,
    onCreate: () -> Unit
) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Servidores de Minecraft") }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = onCreate) { Text("+ Nuevo servidor") }
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp)
        ) {
            item { TermuxSetupCard() }
            if (servers.isEmpty()) {
                item { Text("Aún no tienes servidores. Crea uno con el botón de abajo.") }
            }
            items(servers, key = { it.id }) { s ->
                Card(modifier = Modifier.fillMaxWidth().clickable { onOpen(s) }) {
                    Column(Modifier.padding(16.dp)) {
                        Text(s.name, style = MaterialTheme.typography.titleMedium)
                        Text("${s.edition.label} · ${s.ramMb} MB de RAM")
                    }
                }
            }
        }
    }
}

@Composable
fun TermuxSetupCard() {
    val ctx = LocalContext.current
    var installed by remember { mutableStateOf(TermuxBridge.isInstalled(ctx)) }
    var permitted by remember { mutableStateOf(TermuxBridge.hasPermission(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        permitted = it
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Preparación (una sola vez)", style = MaterialTheme.typography.titleMedium)
            Text(
                if (installed) "✔ Termux instalado"
                else "✘ Falta Termux. Instálalo desde F-Droid o desde su GitHub (la versión de Play Store está vieja)."
            )
            Text("1. Abre Termux y pega este comando. Luego cierra Termux por completo y ábrelo otra vez:")
            Text(TermuxBridge.SETUP_COMMAND, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("comando", TermuxBridge.SETUP_COMMAND))
                    Toast.makeText(ctx, "Comando copiado", Toast.LENGTH_SHORT).show()
                }) { Text("Copiar") }
                OutlinedButton(onClick = { TermuxBridge.openTermux(ctx) }, enabled = installed) {
                    Text("Abrir Termux")
                }
            }
            Text(if (permitted) "✔ Permiso concedido" else "2. Da permiso a esta app para controlar Termux:")
            if (!permitted) {
                Button(onClick = { permLauncher.launch(TermuxBridge.PERMISSION) }, enabled = installed) {
                    Text("Dar permiso")
                }
            }
            Text("3. Quita el ahorro de batería para que Android no cierre el servidor:")
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }) { Text("Ajustes de batería") }
            TextButton(onClick = {
                installed = TermuxBridge.isInstalled(ctx)
                permitted = TermuxBridge.hasPermission(ctx)
            }) { Text("Revisar de nuevo") }
        }
    }
}

@Composable
fun CreateServerDialog(onDismiss: () -> Unit, onCreate: (ServerConfig) -> Unit) {
    val ctx = LocalContext.current
    val totalMb = remember {
        val info = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(info)
        (info.totalMem / (1024L * 1024L)).toInt()
    }
    val maxRam = (totalMb * 6 / 10).coerceAtLeast(768)
    var name by remember { mutableStateOf("Mi servidor") }
    var edition by remember { mutableStateOf(Edition.BEDROCK) }
    var ram by remember { mutableStateOf(minOf(1024, maxRam).toFloat()) }
    var maxPlayers by remember { mutableStateOf("5") }
    var eula by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nuevo servidor") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nombre") },
                    singleLine = true
                )
                Text("Edición")
                Edition.values().forEach { e ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable { edition = e },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = edition == e, onClick = { edition = e })
                        Text(e.label)
                    }
                }
                Text("RAM: ${ram.toInt()} MB (tu teléfono tiene $totalMb MB)")
                Slider(value = ram, onValueChange = { ram = it }, valueRange = 512f..maxRam.toFloat())
                OutlinedTextField(
                    value = maxPlayers,
                    onValueChange = { maxPlayers = it.filter(Char::isDigit).take(3) },
                    label = { Text("Jugadores máximos") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Row(
                    modifier = Modifier.fillMaxWidth().clickable { eula = !eula },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = eula, onCheckedChange = { eula = it })
                    Text("Acepto el EULA de Minecraft (aka.ms/MinecraftEULA)")
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = eula && name.isNotBlank(),
                onClick = {
                    onCreate(
                        ServerConfig(
                            name = name.trim(),
                            edition = edition,
                            ramMb = (ram.toInt() / 64) * 64,
                            maxPlayers = maxPlayers.toIntOrNull()?.coerceAtLeast(1) ?: 5
                        )
                    )
                }
            ) { Text("Crear") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

private fun phaseLabel(p: Phase): String = when (p) {
    Phase.IDLE -> "detenido"
    Phase.SETUP -> "preparando"
    Phase.STARTING -> "iniciando"
    Phase.RUNNING -> "en marcha"
    Phase.STOPPING -> "deteniendo"
}

private fun localIp(): String? = try {
    NetworkInterface.getNetworkInterfaces().toList()
        .filter { it.isUp && !it.isLoopback }
        .flatMap { it.inetAddresses.toList() }
        .firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
        ?.hostAddress
} catch (e: Exception) {
    null
}

private fun launchScript(ctx: Context, phase: Phase, title: String, script: String) {
    if (!TermuxBridge.isInstalled(ctx)) {
        Toast.makeText(ctx, "Instala Termux primero", Toast.LENGTH_LONG).show()
        return
    }
    if (!TermuxBridge.hasPermission(ctx)) {
        Toast.makeText(ctx, "Falta el permiso para controlar Termux (pantalla principal)", Toast.LENGTH_LONG).show()
        return
    }
    ServerService.start(ctx)
    ConsoleHub.begin(phase, title)
    if (!TermuxBridge.runScript(ctx, script)) {
        ConsoleHub.fail("No se pudo contactar con Termux. Revisa el permiso y allow-external-apps.")
    }
}

@Composable
fun ServerScreen(server: ServerConfig, onBack: () -> Unit, onDelete: (ServerConfig) -> Unit) {
    val ctx = LocalContext.current
    val phase = ConsoleHub.phase
    val lines = ConsoleHub.lines
    var command by remember { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val ip = remember { localIp() ?: "IP-del-teléfono" }

    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) listState.scrollToItem(lines.size - 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(server.name) },
                navigationIcon = { TextButton(onClick = onBack) { Text("← Atrás") } },
                actions = {
                    TextButton(onClick = { confirmDelete = true }, enabled = phase == Phase.IDLE) {
                        Text("Borrar")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            modifier = Modifier.padding(pad).padding(12.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("${server.edition.label} · ${server.ramMb} MB · Estado: ${phaseLabel(phase)}")
            val bedrockInfo = if (server.edition == Edition.BEDROCK) "   |   Bedrock: $ip:19132" else ""
            Text("Java: $ip:${server.port}$bedrockInfo", fontFamily = FontFamily.Monospace, fontSize = 12.sp)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    enabled = phase == Phase.IDLE,
                    onClick = {
                        launchScript(ctx, Phase.SETUP, "Preparando servidor...", TermuxBridge.setupScript(ctx, server))
                    }
                ) { Text("Preparar") }
                Button(
                    enabled = phase == Phase.IDLE,
                    onClick = {
                        launchScript(ctx, Phase.STARTING, "Iniciando servidor...", TermuxBridge.startScript(ctx, server))
                    }
                ) { Text("Iniciar") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    enabled = phase == Phase.STARTING || phase == Phase.RUNNING,
                    onClick = { ConsoleHub.requestStop() }
                ) { Text("Detener") }
                OutlinedButton(onClick = {
                    if (phase == Phase.SETUP) {
                        ConsoleHub.fail("Preparación cancelada en la app (Termux puede seguir trabajando en segundo plano).")
                    } else {
                        ConsoleHub.log("[app] Forzando cierre...")
                        TermuxBridge.runScript(ctx, "pkill -f server.jar")
                    }
                }) { Text("Forzar cierre") }
            }

            Surface(
                color = Color.Black,
                modifier = Modifier.weight(1f).fillMaxWidth()
            ) {
                LazyColumn(state = listState, contentPadding = PaddingValues(8.dp)) {
                    items(lines) { line ->
                        Text(
                            line,
                            color = Color(0xFFB8F5B8),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            lineHeight = 14.sp
                        )
                    }
                }
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = command,
                    onValueChange = { command = it },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    enabled = phase == Phase.RUNNING,
                    placeholder = { Text("Comando (ej: say hola)") }
                )
                Button(
                    enabled = phase == Phase.RUNNING && command.isNotBlank(),
                    onClick = {
                        ConsoleHub.log("> ${command.trim()}")
                        ConsoleHub.send(command.trim())
                        command = ""
                    }
                ) { Text("Enviar") }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("¿Borrar servidor?") },
            text = {
                Text("Solo se quita de la app. Los archivos y mundos siguen en Termux, en la carpeta ~/mcservers/${server.dir}")
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDelete(server)
                }) { Text("Borrar") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } }
        )
    }
}
