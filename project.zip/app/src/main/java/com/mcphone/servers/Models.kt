package com.mcphone.servers

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class Edition(val label: String, val key: String) {
    JAVA("Java (Paper)", "java"),
    BEDROCK("Bedrock + Java (Paper + Geyser)", "bedrock")
}

data class ServerConfig(
    val id: String = UUID.randomUUID().toString().take(8),
    val name: String,
    val edition: Edition,
    val version: String = "latest",
    val ramMb: Int = 1024,
    val port: Int = 25565,
    val maxPlayers: Int = 5
) {
    /** Carpeta del servidor dentro de Termux: ~/mcservers/<dir> */
    val dir: String
        get() = name.lowercase()
            .replace(Regex("[^a-z0-9]+"), "-")
            .trim('-')
            .ifEmpty { "server" } + "-" + id
}

object ServerStore {
    private const val PREFS = "servers"
    private const val KEY = "list"

    fun load(ctx: Context): List<ServerConfig> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ServerConfig(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    edition = Edition.valueOf(o.getString("edition")),
                    version = o.optString("version", "latest"),
                    ramMb = o.optInt("ramMb", 1024),
                    port = o.optInt("port", 25565),
                    maxPlayers = o.optInt("maxPlayers", 5)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, list: List<ServerConfig>) {
        val arr = JSONArray()
        list.forEach { s ->
            arr.put(
                JSONObject()
                    .put("id", s.id)
                    .put("name", s.name)
                    .put("edition", s.edition.name)
                    .put("version", s.version)
                    .put("ramMb", s.ramMb)
                    .put("port", s.port)
                    .put("maxPlayers", s.maxPlayers)
            )
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
