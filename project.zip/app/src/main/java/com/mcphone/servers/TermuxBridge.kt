package com.mcphone.servers

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

/** Envía scripts a Termux mediante su intent RUN_COMMAND. */
object TermuxBridge {
    const val PKG = "com.termux"
    const val PERMISSION = "com.termux.permission.RUN_COMMAND"
    const val SETUP_COMMAND =
        "mkdir -p ~/.termux && echo 'allow-external-apps=true' >> ~/.termux/termux.properties"

    private const val BASH = "/data/data/com.termux/files/usr/bin/bash"
    private const val HOME = "/data/data/com.termux/files/home"

    fun isInstalled(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(PKG, 0)
        true
    } catch (e: Exception) {
        false
    }

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, PERMISSION) == PackageManager.PERMISSION_GRANTED

    fun openTermux(ctx: Context) {
        ctx.packageManager.getLaunchIntentForPackage(PKG)?.let { ctx.startActivity(it) }
    }

    /** Ejecuta un script bash en segundo plano dentro de Termux. */
    fun runScript(ctx: Context, script: String): Boolean {
        return try {
            val intent = Intent("com.termux.RUN_COMMAND").apply {
                setClassName(PKG, "com.termux.app.RunCommandService")
                putExtra("com.termux.RUN_COMMAND_PATH", BASH)
                putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", script))
                putExtra("com.termux.RUN_COMMAND_WORKDIR", HOME)
                putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
            }
            ContextCompat.startForegroundService(ctx, intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun setupScript(ctx: Context, s: ServerConfig): String = fill(readAsset(ctx, "setup.sh"), s)

    fun startScript(ctx: Context, s: ServerConfig): String = fill(readAsset(ctx, "start.sh"), s)

    private fun readAsset(ctx: Context, name: String): String =
        ctx.assets.open(name).bufferedReader().use { it.readText() }

    private fun fill(template: String, s: ServerConfig): String {
        val safeVersion = s.version.replace(Regex("[^A-Za-z0-9._-]"), "").ifEmpty { "latest" }
        return template
            .replace("__CONSOLE_PORT__", ConsoleHub.PORT.toString())
            .replace("__DIR__", s.dir)
            .replace("__EDITION__", s.edition.key)
            .replace("__VERSION__", safeVersion)
            .replace("__PORT__", s.port.toString())
            .replace("__MAXPLAYERS__", s.maxPlayers.toString())
            .replace("__RAM__", s.ramMb.toString())
    }
}
